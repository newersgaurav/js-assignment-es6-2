function question1(){
	var array = [1, 1, 2, 5, 4, 3, 1, 2, 8, 9, 4, 6, 5, 4, 2, 3, 1, 7, 8, 4];
    var newArray = new Set(array);
    var arr = Array.from(newArray);
    console.log("array is " + array);
    console.log("Filtered array using set is " + arr);
}

function question2(){
    let map_index = 0;
    let findCombo = function combo(map,str,l,r) {
        if(l == r) {
            map_index++;
            insertInToMap(map,map_index,str);
        }
        else {
            for(let i = l; i <= r; i++) {
                str = swap(str,l,i);
                combo(map,str,l+1,r); 
	            str = swap(str,l,i);      
            }
        }
    }
    let swap = function (a,i,j) { 
	 	let strToArr = a.split('');
		temp = strToArr[i]; 
		strToArr[i] = strToArr[j];
		strToArr[j] = temp; 
		return strToArr.join('');
	} 
    let insertInToMap = function (map,key,value) {
        map.set(key,value);
    } 
    let map = new Map();
    findCombo(map,"abc",0,2);
    console.log(map);
}

function question3(){
	 class Person{
            constructor(name,age){
                this.name = name;
                this.age = age;
            }
            static printPerson(){
                return `${this.name} is ${this.age} years old`;
            }
        }
        class Employee extends Person{
            constructor(name,age,id){
                super(name,age);
                this.id = id;
            }
        }
        class Developer extends Employee{
            constructor(name,age,id,competency){
                super(name,age,id);
                this.competency = competency;
            }
        }
        var dev = new Developer("Gaurav",22,3333,"FEEN");
        console.log(`name is: ${dev.name}, age is: ${dev.age}, id is: ${dev.id}, competancy is: ${dev.competency}`);
}

function question4(){
	class Class{
            static print(){
                return "Static functions are accessed by the class name where they are declared."
            }
        }
        console.log(Class.print());
}

function question7(){
	let flattenArray = (array,final = []) => {
            // final = [];
            for (let i = 0; i < array.length; i++) {
                const value = array[i];
                if (Array.isArray(value)) {
                    flattenArray(value,final);
                } else {
                    final.push(value);
                }
            }
            return final;
        };
        var arr = [1,2,[3,[4,5],6],7];
        console.log(arr);
        console.log("flatten array is:");
        console.log(flattenArray(arr))
}

function question8(){
	class LinkedListimplementation {
            constructor(array = []) {
                    this.array = array;
            }
            length() {
                return this.array.length
            }
            getFirst() {
                if (this.array.length === 0) {
                    console.log("empty linked list!!!")
                }
                return this.array[0];
            }
            getLast() {
                if (this.array.length === 0) {
                    console.log("empty linked list!!!")
                }
                return this.array[this.array.length - 1]
            }
            addFirst(value) {
                this.array.unshift(value);
                return this.array;
            }
            addLast(value) {
                this.array.push(value);
                return this.array;
            }
        }
        //Testing linked list
        var linkedlist = new LinkedListimplementation();
        console.log("Added 2 in Start : " + linkedlist.addFirst(2));
        console.log("Added 3 in Last : " + linkedlist.addLast(3));
        console.log("Added 1 in Last : " + linkedlist.addLast(1));
        console.log("Added 4 in First : " + linkedlist.addFirst(4));
        console.log("First element : " + linkedlist.getFirst());
        console.log("Last element : " + linkedlist.getLast());
        console.log("Lenght : " + linkedlist.length()); 
}

function question9(){
	console.log("!!!***Implementation of MAP***!!!")
        var map = new Map();
        var first = "string";
        var second = {};
        var third = function(){};
        var fourth = NaN;
        map.set(first, "Value of first");
        map.set(second, "Value of second");
        map.set(third, "Value of third");
        map.set(fourth, "Value of fourth");
        console.log("\nSize of Map: "+map.size);
        console.log("\nfirst Key and its string using key name: "+ map.get(first));
        console.log("first Key and its string using key value: "+ map.get("string"));
        console.log("\nsecond Key and its string using key name: "+ map.get(second));
        console.log("second Key and its string using key value: "+ map.get({}));
        console.log("\nthird Key and its string using key name: "+ map.get(third));
        console.log("\nfourth Key and its string using key name: "+ map.get(fourth));
        console.log("\n\n!!!***Implementation of SET***!!!")
        var set = new Set();
        console.log("adding : " , set.add(1));
        console.log("adding : " , set.add(2));
        console.log("adding : " , set.add(2));
        console.log("adding : " , set.add(1));
        console.log("adding : " , set.add(3));
        console.log("set has 3?: " + set.has(3));
        console.log("Size of SET : ", set.size);
        console.log("Deleting 1 : " , set.delete(1));
        console.log("Current state of SET : ", set)
}

function question10(){
	 class Stack {
            constructor(arr = []) {
                    this.arr = arr;
            }
            push(element) {
                this.arr.push(element);
                return this.arr;
            }
            pop(element) {
                if (this.arr.length === 0) {
                    alert("Empty array!!!")
                }
                return this.arr.pop();
            }
        }
        //implementation
        let stack = new Stack();
        console.log(stack.push(1) + " : Pushed!");
        console.log(stack.push(2) + " : Pushed!");
        console.log(stack.push(3) + " : Pushed!");
        
        console.log(stack.pop() + " : Popped!");
        console.log(stack.pop() + " : Popped!");
        console.log("Stack image : ",stack);

}